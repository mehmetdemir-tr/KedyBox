// PatiOS Security Patch Tool

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <openssl/sha.h>
#include <sys/socket.h>
#include <netdb.h>

#define DB_DIR "/lib/psp/db"
#define CACHE_DIR "/lib/psp/cache"
#define SERVER "mirror.corvora.org"
#define PATCHES_PATH "/pati/patches/patches.json"

char *strnstr(const char *haystack, const char *needle, size_t len) {
    size_t needle_len = strlen(needle);
    if (!needle_len) return (char *)haystack;
    for (size_t i = 0; i < len && haystack[i]; i++) {
        if (i + needle_len > len) break;
        if (memcmp(haystack + i, needle, needle_len) == 0)
            return (char *)(haystack + i);
    }
    return NULL;
}

int dosya_sha256(const char *path, unsigned char out[32]) {
    FILE *f = fopen(path, "rb");
    if (!f) return -1;
    SHA256_CTX ctx;
    SHA256_Init(&ctx);
    unsigned char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0) {
        SHA256_Update(&ctx, buf, n);
    }
    fclose(f);
    SHA256_Final(out, &ctx);
    return 0;
}

void hash_to_str(unsigned char hash[32], char out[65]) {
    for (int i = 0; i < 32; i++) {
        sprintf(out + i * 2, "%02x", hash[i]);
    }
    out[64] = 0;
}

int http_get(const char *host, const char *path, char *buf, size_t bufsz) {
    struct addrinfo hints = {.ai_family = AF_INET, .ai_socktype = SOCK_STREAM};
    struct addrinfo *res;
    if (getaddrinfo(host, "80", &hints, &res) != 0) return -1;
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (connect(fd, res->ai_addr, res->ai_addrlen)) { close(fd); return -1; }
    freeaddrinfo(res);

    char req[512];
    snprintf(req, sizeof(req), "GET %s HTTP/1.0\r\nHost: %s\r\n\r\n", path, host);
    write(fd, req, strlen(req));

    int n = read(fd, buf, bufsz - 1);
    close(fd);
    if (n <= 0) return -1;
    buf[n] = 0;

    char *body = strnstr(buf, "\r\n\r\n", n);
    if (!body) return -1;
    body += 4;
    memmove(buf, body, strlen(body) + 1);
    return 0;
}

int json_oku_hash(const char *json, const char *dosya_yolu, unsigned char hash[32]) {
    char search[256];
    snprintf(search, sizeof(search), "\"%s\": \"", dosya_yolu);
    char *p = strstr(json, search);
    if (!p) return -1;
    p += strlen(search);
    char hex[65];
    int i;
    for (i = 0; i < 64 && p[i] && p[i] != '"'; i++)
        hex[i] = p[i];
    hex[i] = 0;
    for (i = 0; i < 32; i++)
        sscanf(hex + i * 2, "%2hhx", &hash[i]);
    return 0;
}

int json_oku_dosya(const char *json, const char *dosya_yolu, 
                   unsigned char hash[32], char *url, size_t url_sz) {
    char search[256];
    snprintf(search, sizeof(search), "\"%s\": {", dosya_yolu);
    char *p = strstr(json, search);
    if (!p) return -1;

    p = strnstr(p, "\"sha256\": \"", json + strlen(json) - p);
    if (!p) return -1;
    p += 11;
    char hex[65];
    int i;
    for (i = 0; i < 64 && p[i] && p[i] != '"'; i++) hex[i] = p[i];
    hex[i] = 0;
    for (i = 0; i < 32; i++) sscanf(hex + i * 2, "%2hhx", &hash[i]);

    p = strnstr(p, "\"url\": \"", json + strlen(json) - p);
    if (!p) return -1;
    p += 7;
    for (i = 0; p[i] && p[i] != '"' && i < (int)url_sz - 1; i++) url[i] = p[i];
    url[i] = 0;
    return 0;
}

int http_get_file(const char *host, const char *path, const char *outfile) {
    char buf[4096];
    struct addrinfo hints = {.ai_family = AF_INET, .ai_socktype = SOCK_STREAM};
    struct addrinfo *res;
    if (getaddrinfo(host, "80", &hints, &res)) return -1;
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (connect(fd, res->ai_addr, res->ai_addrlen)) { close(fd); return -1; }
    freeaddrinfo(res);

    char req[512];
    snprintf(req, sizeof(req), "GET %s HTTP/1.0\r\nHost: %s\r\n\r\n", path, host);
    write(fd, req, strlen(req));

    int out = open(outfile, O_WRONLY | O_CREAT | O_TRUNC, 0755);
    if (out < 0) { close(fd); return -1; }

    int n;
    int body = 0;
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
        if (!body) {
            char *hdr_end = strnstr(buf, "\r\n\r\n", n);
            if (hdr_end) {
                body = 1;
                hdr_end += 4;
                int remain = n - (hdr_end - buf);
                if (remain > 0) write(out, hdr_end, remain);
            }
        } else {
            write(out, buf, n);
        }
    }
    close(fd);
    close(out);
    return 0;
}

int cmd_check() {
    printf("Sunucu kontrol ediliyor..\n");

    char json[8192];
    if (http_get(SERVER, PATCHES_PATH, json, sizeof(json))) {
        printf("HATA: Sunucuya erişilemedi, lütfen daha sonra tekrar deneyin.\n");
        return -1;
    }

    int uyumsuz = 0, tamam = 0, eksik = 0;
    char *p = json;
    while ((p = strnstr(p, "\"/", json + sizeof(json) - p)) != NULL) {
        p++;
        char dosya[256];
        int i = 0;
        while (*p && *p != '"' && i < 255)
            dosya[i++] = *p++;
        dosya[i] = 0;
        if (i == 0) continue;

        unsigned char beklenen_hash[32], gercek_hash[32];
        if (json_oku_hash(json, dosya, beklenen_hash)) {
            printf("[?!] %s - hash doğrulanamadı.\n", dosya);
            continue;
        if (dosya_sha256(dosya, gercek_hash)) {
            printf("[!] %s - dosya bulunamadı.\n", dosya);
            eksik++;
            continue;
        }
        if (memcmp(beklenen_hash, gercek_hash, 32) == 0) {
            printf("[+] Doğrulandı! bu zararsız.\n", dosya);
            tamam++;
            continue;
        } else {
            printf("[!!!] %s Bu patch dosyası uyumsuz.\n");
            uyumsuz++;
        }

        }

    }
    printf("\nÖzet: %d tamam, %d uyumsuz, %d eksik\n", tamam, uyumsuz, eksik);
    return uyumsuz > 0 ? 2 : 0;
}

int cmd_guncelle() {
    printf("Güncellemeler kontrol ediliyor...\n");

    char json[16384];
    if (http_get(SERVER, PATCHES_PATH, json, sizeof(json))) {
        printf("HATA: Sunucuya erişilemedi.\n");
        return -1;
    }

    mkdir("/lib/psp", 0755);
    mkdir("/lib/psp/yedek", 0755);
    mkdir("/lib/psp/cache", 0755);

    int guncellenen = 0;
    char *p = json;
    while ((p = strnstr(p, "\"/", json + sizeof(json) - p)) != NULL) {
        p++;
        char dosya[256];
        int i = 0;
        while (*p && *p != '"' && i < 255) dosya[i++] = *p++;
        dosya[i] = 0;
        if (i == 0) continue;

        unsigned char beklenen[32], gercek[32];
        char url[256];
        if (json_oku_dosya(json, dosya, beklenen, url, sizeof(url))) continue;

        if (dosya_sha256(dosya, gercek) == 0 && memcmp(beklenen, gercek, 32) == 0) {
            printf(" [+] %s — güncel\n", dosya);
            continue;
        }

        printf(" [?] %s — güncelleniyor...\n", dosya);

        char yedek[512];
        snprintf(yedek, sizeof(yedek), "/lib/psp/yedek/%s", strrchr(dosya, '/') ? strrchr(dosya, '/') + 1 : dosya);
        rename(dosya, yedek);

        char cache[512];
        snprintf(cache, sizeof(cache), "/lib/psp/cache/%s.tmp", strrchr(url, '/') ? strrchr(url, '/') + 1 : url);
        if (http_get_file(SERVER, url, cache)) {
            printf(" [!] %s — indirme başarısız, yedek geri alınıyor.\n", dosya);
            rename(yedek, dosya);
            continue;
        }

        rename(cache, dosya);
        chmod(dosya, 0755);

        if (dosya_sha256(dosya, gercek) == 0 && memcmp(beklenen, gercek, 32) == 0) {
            printf(" [+] %s — güncellendi\n", dosya);
            guncellenen++;
        } else {
            printf(" [!] %s — hash uyuşmazlığı, yedek geri alınıyor.\n", dosya);
            rename(yedek, dosya);
        }
    }

    printf("\n%d dosya güncellendi.\n", guncellenen);
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        printf("Kullanım: psp <komut>\n");
        printf("Komutlar:\n");
        printf("kontrolet = Sistem bütünlük kontrolü. \n");
        return 1;
    }
    if (!strcmp(argv[1], "kontrolet"))
        return cmd_check();
    else if (!strcmp(argv[1], "güncelle"))
        return cmd_guncelle();
    else
        printf("Bilinmeyen komut: %s\n", argv[1]);
    return 1;
}